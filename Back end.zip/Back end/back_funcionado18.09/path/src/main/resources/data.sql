/*INSERT INTO leitura (sensor_id, nivel_agua, status, distancia, data_hora) VALUES
('SENSOR_01', 5.0, 'NORMAL', 195.0, NOW()),
('SENSOR_01', 12.0, 'ATENÇÃO', 188.0, NOW()),
('SENSOR_01', 18.0, 'CRÍTICO', 182.0, NOW()),
('SENSOR_02', 4.0, 'NORMAL', 196.0, NOW()),
('SENSOR_02', 11.0, 'ATENÇÃO', 189.0, NOW()),
('SENSOR_03', 6.0, 'NORMAL', 194.0, NOW()),
('SENSOR_03', 16.0, 'CRÍTICO', 184.0, NOW());*/
