package com.flood.path.controller;

import com.flood.path.entity.Rio;
import com.flood.path.entity.Usuario;
import com.flood.path.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/usuario")
@CrossOrigin("*")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @GetMapping
    public List<Usuario>listarUsuario(){
        return this.service.listarUsuarios();
    }

    @PostMapping ("/{id}")
    public void salvar(@PathVariable Long id, @RequestBody Usuario usuario){
        this.service.salvar(usuario);
    }
    @PutMapping ("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody Usuario usuario){
        this.service.atualizar(id, usuario);
    }
    @DeleteMapping ("/{id}")
    public void delete(@PathVariable Long id){
        service.delete(id);
    }

}
