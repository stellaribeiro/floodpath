package com.flood.path.service;

import com.flood.path.entity.Rio;
import com.flood.path.repository.RioRepository;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RioService {

    private final RioRepository repository;

    private static final double LIMITE_ATENCAO = 10.0;
    private static final double LIMITE_CRITICO = 15.0;

    public RioService(RioRepository repository) {
        this.repository = repository;
    }

    public Rio receberLeitura(Rio rio) {
        double alturaEixoY = rio.getNivelAgua() != null ? rio.getNivelAgua() : 0.0;
        if (alturaEixoY >= LIMITE_CRITICO) {
            rio.setStatus("CRÍTICO ");
        } else if (alturaEixoY >= LIMITE_ATENCAO) {
            rio.setStatus("ATENÇÃO");

        } else {
            rio.setStatus("NORMAL");
        }
        return repository.save(rio);

    }


    public List<Rio> listarRecentes(int limite) {
        return repository.findAll()
                .stream()
                .sorted((a, b) -> b.getDataHora().compareTo(a.getDataHora()))
                .limit(limite)
                .toList();
    }

}
