package com.flood.path.service;

import com.flood.path.entity.Rio;
import com.flood.path.repository.RioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RioService {

    @Autowired
    private RioRepository repository;

    public List<Rio> listarTodo(Long id, double nivelAgua) {
        List<Rio> listaRisco = new ArrayList<>();
        Rio rio = repository.findById(id).orElse(null);

        if (rio != null) {
            String risco;
            if (nivelAgua == 0) {
                risco = "RISCO BAIXO - NÍVEL NORMAL";
            } else if (nivelAgua == 2) {
                risco = "RISCO MODERADO - ATENÇÃO";
            } else if (nivelAgua > 2) {
                risco = "RISCO CRÍTICO - ALERTA DE ENCHENTE";
            } else {
                risco = "DADOS DE NÍVEL INVÁLIDOS";
            }

            // Transforma o Rio em RioRiscoDTO com a classificação calculada
            Rio dto = new Rio(rio.getId(), nivelAgua, risco);
        }

        return listaRisco;
    }

    public Rio salvar(Rio rio) {
        return repository.save(rio);
    }

    public void deletar(Long id) {
        this.repository.deleteById(id);
    }

    public void atualizar(Long id, Rio dto) {
        Rio rioAtualizado= repository.getReferenceById(id);
             if (rioAtualizado == null){
                 System.out.println("Rio não encontrado");
             }else{
                 rioAtualizado.setNivelAgua(dto.getNivelAgua());
             }
    }

    public void delete(Long id){
        repository.deleteById(id);
    }
}
