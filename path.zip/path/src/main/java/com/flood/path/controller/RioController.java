package com.flood.path.controller;


import com.flood.path.entity.Rio;
import com.flood.path.service.RioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/floodpath/rio")
@CrossOrigin("*")
public class RioController {

    @Autowired
    private RioService service;

    @GetMapping("/{id}")
    public List<Rio> listarTodo(
            @PathVariable Long id,
            @RequestParam double nivelAgua

    ) {
        return service.listarTodo(id, nivelAgua);
    }


    @PostMapping ("/{id}")
    public void salvar(@PathVariable Long id, @RequestBody Rio dto){
        this.service.salvar(dto);
    }

    @PutMapping ("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody Rio dto){
        this.service.atualizar(id, dto);
    }

    @DeleteMapping ("/{id}")
    public void delete(@PathVariable Long id){
        service.delete(id);
    }


}
