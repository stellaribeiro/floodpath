package com.flood.path.controller;

import com.flood.path.entity.Rio;
import com.flood.path.service.RioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/path")
@CrossOrigin(origins = "*")
public class RioController {

    private final RioService service;

    public RioController(RioService service) {
        this.service = service;
    }

    @GetMapping
    public List<Rio> listar(@RequestParam(defaultValue = "50") int limite) {
        return service.listarRecentes(limite);
    }

    @PostMapping
    public Rio receber(@RequestBody Rio rio) {
        return service.receberLeitura(rio);
    }
}
