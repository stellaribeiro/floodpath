package com.flood.path.repository;


import com.flood.path.entity.Rio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RioRepository extends JpaRepository<Rio, Long> {
    List<Rio> findByIdAndNivelAguaAndRisco(Long id, double nivelAgua, String risco);
}
