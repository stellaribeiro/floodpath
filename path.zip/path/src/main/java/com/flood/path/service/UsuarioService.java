package com.flood.path.service;

import com.flood.path.entity.Rio;
import com.flood.path.entity.Usuario;
import com.flood.path.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

  @Autowired
  private UsuarioRepository repository;

  public List<Usuario> listarUsuarios(){
      return repository.findAll();
  }

  public Usuario salvar(Usuario usuario) {
        return repository.save(usuario);
  }

  public void atualizar(Long id, Usuario usuario) {
        Usuario usuarioAtualizado = repository.getReferenceById(id);
        if (usuarioAtualizado == null){
            System.out.println("Rio não encontrado");
        }else{
            usuarioAtualizado.setId(usuario.getId());
            usuarioAtualizado.setLatitude(usuario.getLatitude());
            usuarioAtualizado.setLongitude(usuario.getLongitude());
        }
  }

    public void delete(Long id){
        repository.deleteById(id);
    }
}
