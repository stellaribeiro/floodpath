package com.flood.path.service;

import com.flood.path.entity.Rio;
import com.flood.path.entity.Sensor;
import com.flood.path.repository.RioRepository;
import com.flood.path.repository.SensorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SensorService {
    @Autowired
    private SensorRepository repository;

    public List<Sensor> listarTodo() {
        return repository.findAll();
    }
    public Sensor salvar(Sensor sensor) {
        return repository.save(sensor);
    }

    public void atualizar(Long id, Sensor sensor) {
        Sensor sensorAtualizado= repository.getReferenceById(id);
        if (sensorAtualizado == null){
            System.out.println("Rio não encontrado");
        }else{
            sensorAtualizado.setNivelAgua(sensor.getNivelAgua());
        }
    }
    public void delete(Long id){
        repository.deleteById(id);
    }
}
