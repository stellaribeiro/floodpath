// ==========================================
// 1. CONFIGURAÇÕES E CONSTANTES (INTACTAS)
// ==========================================
const ORS_API_KEY = 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImIyOTM5MjhlNzFiMTRjOTM4MTA5NDhiOWNkNTliMGEwIiwiaCI6Im11cm11cjY0In0='; 

const pontoOrigem = [-47.8972, -22.0233]; // Ponto de partida fixo

// Coordenadas dos pontos monitorizados
const COORDS_CRISTO = [-47.9095, -22.0180]; // SENSOR_01
const COORDS_SESC   = [-47.9058, -22.0167]; // SENSOR_02

const RAIO_BLOQUEIO_METROS = 250; 

const coordsOrigemOverlay = ol.proj.fromLonLat(pontoOrigem);
const coordsCristoOverlay = ol.proj.fromLonLat(COORDS_CRISTO);
const coordsSescOverlay   = ol.proj.fromLonLat(COORDS_SESC);

const destinosFixos = {
    'shopping': [-47.9170, -22.0185],
    'cristo': COORDS_CRISTO,
    'sesc': COORDS_SESC
};

// ==========================================
// 2. INICIALIZAÇÃO DO MAPA E CAMADAS
// ==========================================
const vetorSource = new ol.source.Vector();
const vetorLayer = new ol.layer.Vector({
    source: vetorSource,
    style: new ol.style.Style({
        stroke: new ol.style.Stroke({ color: '#3b82f6', width: 6 })
    })
});

const map = new ol.Map({
    target: 'map-container',
    layers: [
        new ol.layer.Tile({ source: new ol.source.OSM() }),
        vetorLayer
    ],
    view: new ol.View({
        center: ol.proj.fromLonLat(pontoOrigem),
        zoom: 14
    })
});

// ==========================================
// 3. VINCULAÇÃO DOS OVERLAYS
// ==========================================
const elUser = document.getElementById('overlay-user');
if (elUser) {
    map.addOverlay(new ol.Overlay({ element: elUser, position: coordsOrigemOverlay, positioning: 'center-center' }));
}

const elBloqueio = document.getElementById('overlay-bloqueio');
if (elBloqueio) {
    map.addOverlay(new ol.Overlay({ element: elBloqueio, position: coordsCristoOverlay, positioning: 'center-center' }));
}

const elSubindo = document.getElementById('overlay-subindo');
if (elSubindo) {
    map.addOverlay(new ol.Overlay({ element: elSubindo, position: coordsSescOverlay, positioning: 'center-center' }));
}

// Overlay do Destino Final
const elDestino = document.getElementById('overlay-destino');
let overlayDestino = null;

if (elDestino) {
    overlayDestino = new ol.Overlay({ 
        element: elDestino, 
        positioning: 'center-center' 
    });
    map.addOverlay(overlayDestino);
}

// ==========================================
// 4. AUXILIARES E PROCESSAMENTO DE ROTA
// ==========================================
function calcularDistanciaMetros(coords1, coords2) {
    const R = 6371e3;
    const rad = Math.PI / 180;
    const dLat = (coords2[1] - coords1[1]) * rad;
    const dLon = (coords2[0] - coords1[0]) * rad;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(coords1[1] * rad) * Math.cos(coords2[1] * rad) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

async function tracarR() {
    // DESBLOQUEIA A VOZ NO CLIQUE DO BOTÃO
    if (window.VozNavegacao && typeof window.VozNavegacao.desbloquearAudio === 'function') {
        window.VozNavegacao.desbloquearAudio();
    }

    const inputDestino = document.getElementById('destination') || document.querySelector('input[type="text"]');
    let enderecoDigitado = inputDestino ? inputDestino.value.trim() : '';

    if (!enderecoDigitado) {
        alert('Por favor, digite um endereço de destino!');
        return;
    }

    const buscaMin = enderecoDigitado.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    let destinoCoordenadas = null;

    if (buscaMin.includes('sesc')) {
        destinoCoordenadas = destinosFixos['sesc'];
    } else if (buscaMin.includes('shopping') || buscaMin.includes('iguatemi')) {
        destinoCoordenadas = destinosFixos['shopping'];
    } else if (buscaMin.includes('cristo')) {
        destinoCoordenadas = destinosFixos['cristo'];
    } else {
        const textoComContexto = `${enderecoDigitado}, São Carlos, SP, Brasil`;
        destinoCoordenadas = await buscarCoordenadasPorEndereco(textoComContexto);
    }

    if (!destinoCoordenadas) {
        alert('Endereço não encontrado em São Carlos.');
        return;
    }

    processarRotaComSeguranca(destinoCoordenadas);
}

function processarRotaComSeguranca(coordsDestino) {
    const s1Alagado = (window.statusSensor01 === 'ATENÇÃO' || window.statusSensor01 === 'CRÍTICO');
    const s2Alagado = (window.statusSensor02 === 'ATENÇÃO' || window.statusSensor02 === 'CRÍTICO');

    const distCristo = calcularDistanciaMetros(coordsDestino, COORDS_CRISTO);
    const distSesc   = calcularDistanciaMetros(coordsDestino, COORDS_SESC);

    if (s1Alagado && distCristo <= RAIO_BLOQUEIO_METROS) {
        vetorSource.clear();
        if (typeof window.exibirAlertaBloqueioDestino === 'function') {
            window.exibirAlertaBloqueioDestino('O destino escolhido está na área inundada do Cristo.');
        } else {
            alert('O destino escolhido está numa área de risco alagada.');
        }
        return;
    }

    if (s2Alagado && distSesc <= RAIO_BLOQUEIO_METROS) {
        vetorSource.clear();
        if (typeof window.exibirAlertaBloqueioDestino === 'function') {
            window.exibirAlertaBloqueioDestino('O destino escolhido está na área inundada do SESC.');
        } else {
            alert('O destino escolhido está numa área de risco alagada.');
        }
        return;
    }

    buscarRotaNaAPI(pontoOrigem, coordsDestino, s1Alagado, s2Alagado);
}

async function buscarCoordenadasPorEndereco(texto) {
    const url = `https://api.openrouteservice.org/geocode/search?api_key=${ORS_API_KEY}&text=${encodeURIComponent(texto)}&boundary.rect=-48.00,-22.10,-47.80,-21.90`;
    try {
        const resposta = await fetch(url);
        const dados = await resposta.json();
        return (dados.features && dados.features.length > 0) ? dados.features[0].geometry.coordinates : null;
    } catch {
        return null;
    }
}

function buscarRotaNaAPI(origem, destino, desviarP1, desviarP2) {
    const url = 'https://api.openrouteservice.org/v2/directions/driving-car/geojson';

    const dados = { 
        coordinates: [origem, destino],
        instructions: true,
        language: "pt"
    };
    
    const poligonosEvitar = [];

    if (desviarP1) {
        poligonosEvitar.push([
            [-47.9125, -22.0210],
            [-47.9065, -22.0210],
            [-47.9065, -22.0150],
            [-47.9125, -22.0150],
            [-47.9125, -22.0210]
        ]);
    }

    if (desviarP2) {
        poligonosEvitar.push([
            [-47.9088, -22.0197],
            [-47.9028, -22.0197],
            [-47.9028, -22.0137],
            [-47.9088, -22.0137],
            [-47.9088, -22.0197]
        ]);
    }

    if (poligonosEvitar.length > 0) {
        dados.options = {
            avoid_polygons: {
                type: "MultiPolygon",
                coordinates: poligonosEvitar.map(p => [p])
            }
        };
    }

    fetch(url, {
        method: 'POST',
        headers: { 
            'Authorization': ORS_API_KEY, 
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify(dados)
    })
    .then(r => r.json())
    .then(resultado => {
        if (resultado.features && resultado.features.length > 0) {
            vetorSource.clear();
            
            // 1. Renderiza a Rota no Mapa
            const format = new ol.format.GeoJSON();
            const rota = format.readFeature(resultado.features[0], {
                dataProjection: 'EPSG:4326',
                featureProjection: 'EPSG:3857'
            });
            vetorSource.addFeature(rota);

            // 2. Posiciona o Marcador do Destino Final
            if (overlayDestino && elDestino) {
                const coordsDestinoProj = ol.proj.fromLonLat(destino);
                overlayDestino.setPosition(coordsDestinoProj);
                elDestino.style.display = 'flex';
                
                const labelDestino = document.getElementById('label-destino');
                if (labelDestino) {
                    const inputVal = document.getElementById('destination')?.value;
                    labelDestino.innerText = inputVal ? inputVal.toUpperCase() : 'DESTINO FINAL';
                }
            }

            // 3. Ajusta a visão do mapa
            map.getView().fit(vetorSource.getExtent(), { padding: [60, 60, 60, 60], duration: 1000 });

            // 4. DISPARA A NAVEGAÇÃO POR VOZ
            if (window.VozNavegacao && resultado.features[0].properties.segments) {
                const segmento = resultado.features[0].properties.segments[0];
                window.VozNavegacao.iniciarRota(segmento);
            }

        } else {
            alert('Não foi possível calcular uma rota segura desviando dos pontos alagados.');
        }
    })
    .catch(err => {
        console.error('Erro na API ORS:', err);
        alert('Erro ao calcular a rota segura.');
    });
}

function toggleFullscreen() {
    const mapElement = document.getElementById('map-container');
    const btnIcon = document.querySelector('#btn-fullscreen i');
    if (!document.fullscreenElement) {
        if (mapElement.requestFullscreen) mapElement.requestFullscreen();
        if (btnIcon) btnIcon.className = 'fas fa-compress';
    } else {
        if (document.exitFullscreen) document.exitFullscreen();
        if (btnIcon) btnIcon.className = 'fas fa-expand';
    }
}

document.addEventListener('fullscreenchange', () => setTimeout(() => map.updateSize(), 200));

window.tracarR = tracarR;
window.toggleFullscreen = toggleFullscreen;
window.calcularDistanciaMetros = calcularDistanciaMetros;

document.addEventListener('DOMContentLoaded', () => {
    const inputDestino = document.getElementById('destination') || document.querySelector('input[type="text"]');
    if (inputDestino) {
        inputDestino.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') tracarR();
        });
    }
});