// main.js - Espelhamento em Tempo Real dos Sensores do Banco de Dados
console.log('Sistema de monitoramento e rotas inicializado.');

const API_URL = 'http://localhost:8080/api/rios';

// Variáveis globais contendo o STATUS EXATO vindo do banco
window.statusSensor01 = 'NORMAL';
window.statusSensor02 = 'NORMAL';
window.statusAtualMaquete = 'NORMAL';

async function buscarDadosDoRio() {
    try {
        // Realiza as requisições para o backend Java
        const req1 = fetch(`${API_URL}?sensorId=SENSOR_01&limite=1`).then(r => r.ok ? r.json() : []);
        const req2 = fetch(`${API_URL}?sensorId=SENSOR_02&limite=1`).then(r => r.ok ? r.json() : []);

        const [res1, res2] = await Promise.all([req1, req2]);

        // Extrai o registro correto, seja o retorno um Array [] ou Objeto {}
        let sensor1 = Array.isArray(res1) ? res1[0] : res1;
        let sensor2 = Array.isArray(res2) ? res2[0] : res2;

        // SE O BACKEND RETORNAR A LISTA COMPLETA NAS DUAS REQUISIÇÕES (Caso o Spring Boot não filtre query params)
        if (Array.isArray(res1) && res1.length > 1) {
            sensor1 = res1.find(s => s.sensorId === 'SENSOR_01' || s.nome === 'Cristo') || res1[0];
            sensor2 = res1.find(s => s.sensorId === 'SENSOR_02' || s.nome === 'SESC') || res1[1];
        }

        // 1. Atualiza variáveis globais de status de forma isolada
        window.statusSensor01 = (sensor1 && sensor1.status) ? sensor1.status.toUpperCase() : 'NORMAL';
        window.statusSensor02 = (sensor2 && sensor2.status) ? sensor2.status.toUpperCase() : 'NORMAL';

        // Log de verificação no Console do F12
        console.log(`[SENSORS LOG] Cristo (S1): ${window.statusSensor01} | SESC (S2): ${window.statusSensor02}`);

        // 2. Determina o estado geral exibido no Card Principal
        let statusGeral = 'NORMAL';
        if (window.statusSensor01 === 'CRÍTICO' || window.statusSensor02 === 'CRÍTICO') {
            statusGeral = 'CRÍTICO';
        } else if (window.statusSensor01 === 'ATENÇÃO' || window.statusSensor02 === 'ATENÇÃO') {
            statusGeral = 'ATENÇÃO';
        }
        window.statusAtualMaquete = statusGeral;

        // 3. Elementos visuais da tela
        const statusBox = document.querySelector('.status-box h3');
        const statusDesc = document.querySelector('.status-box p');
        const viasCount = document.getElementById('vias-count');
        const alagamentosCount = document.getElementById('alagamentos-count');

        if (statusBox) {
            statusBox.innerText = `Estado de ${statusGeral}`;
        }

        if (statusDesc) {
            const txtS1 = sensor1 ? `[Cristo] Nível: ${sensor1.nivelAgua ?? 'N/A'}m` : '[Cristo] Sem Dados';
            const txtS2 = sensor2 ? `[SESC] Nível: ${sensor2.nivelAgua ?? 'N/A'}m` : '[SESC] Sem Dados';
            statusDesc.innerText = `${txtS1} | ${txtS2}`;
        }

        // 4. Contadores Dinâmicos
        let vias = 0;
        let alagamentos = 0;

        if (window.statusSensor01 === 'ATENÇÃO') { vias += 1; alagamentos += 1; }
        if (window.statusSensor01 === 'CRÍTICO') { vias += 3; alagamentos += 2; }

        if (window.statusSensor02 === 'ATENÇÃO') { vias += 1; alagamentos += 1; }
        if (window.statusSensor02 === 'CRÍTICO') { vias += 2; alagamentos += 1; }

        if (viasCount) viasCount.innerText = vias < 10 ? `0${vias}` : `${vias}`;
        if (alagamentosCount) alagamentosCount.innerText = alagamentos < 10 ? `0${alagamentos}` : `${alagamentos}`;

        // 5. Atualiza marcadores do mapa individualmente
        atualizarMarcadorMapa('overlay-bloqueio', 'label-bloqueio', window.statusSensor01);
        atualizarMarcadorMapa('overlay-subindo', 'label-subindo', window.statusSensor02);

    } catch (erro) {
        console.error("Erro ao conectar com o back-end Java:", erro);
    }
}

// Oculta ou Exibe os balões no mapa estritamente baseado no banco
function atualizarMarcadorMapa(idOverlay, idLabel, statusDoBanco) {
    const elOverlay = document.getElementById(idOverlay);
    const labelOverlay = document.getElementById(idLabel);

    if (!elOverlay) return;

    elOverlay.classList.remove('status-critico', 'status-atencao');

    if (statusDoBanco === 'CRÍTICO') {
        elOverlay.style.display = 'flex';
        elOverlay.classList.add('status-critico');
        if (labelOverlay) labelOverlay.innerText = 'ÁREA INUNDADA';
    } else if (statusDoBanco === 'ATENÇÃO') {
        elOverlay.style.display = 'flex';
        elOverlay.classList.add('status-atencao');
        if (labelOverlay) labelOverlay.innerText = 'NÍVEL SUBINDO';
    } else {
        elOverlay.style.display = 'none';
        if (labelOverlay) labelOverlay.innerText = '';
    }
}

// Polling contínuo
document.addEventListener('DOMContentLoaded', () => {
    buscarDadosDoRio();
    setInterval(buscarDadosDoRio, 2000);
});

// Toast Alerta para Rotas
function exibirAlertaBloqueioDestino(mensagem) {
    const containerAlerta = document.getElementById('mensagem-sistema') || document.body;

    const alertaAntigo = document.querySelector('.toast-alerta-bloqueio');
    if (alertaAntigo) alertaAntigo.remove();

    const divAlerta = document.createElement('div');
    divAlerta.className = 'toast-alerta-bloqueio';
    divAlerta.innerHTML = `
        <div class="toast-content" style="display:flex; align-items:center; gap:10px;">
            <i class="fas fa-ban" style="font-size:1.5rem;"></i>
            <div>
                <strong>ROTA BLOQUEADA!</strong>
                <p style="margin:0; font-size:0.85rem;">${mensagem || 'O destino selecionado está em uma zona inundada.'}</p>
            </div>
        </div>
    `;

    containerAlerta.appendChild(divAlerta);

    setTimeout(() => {
        divAlerta.remove();
    }, 4500);
}
window.exibirAlertaBloqueioDestino = exibirAlertaBloqueioDestino;