/* ============================================================
   VOZ.JS - Navegação Guiada por Voz
   ============================================================ */

const VozNavegacao = {
    passosRota: [],
    passoAtualIndex: 0,
    watchId: null,
    audioAtivo: false,

    // Liberta a permissão de áudio do navegador no clique
    desbloquearAudio: function () {
        if ('speechSynthesis' in window && !this.audioAtivo) {
            const ut = new SpeechSynthesisUtterance('');
            window.speechSynthesis.speak(ut);
            this.audioAtivo = true;
        }
    },

    falar: function (texto) {
        if (!('speechSynthesis' in window)) return;

        window.speechSynthesis.cancel(); // Limpa falas anteriores

        const utterance = new SpeechSynthesisUtterance(texto);
        utterance.lang = 'pt-BR';
        utterance.rate = 1.0;
        utterance.pitch = 1.0;

        window.speechSynthesis.speak(utterance);
    },

    parar: function () {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        if (this.watchId !== null) {
            navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        }
    },

    iniciarRota: function (segmentoOSRM) {
        this.parar();

        const distanciaKm = (segmentoOSRM.distance / 1000).toFixed(1);
        const tempoMin = Math.round(segmentoOSRM.duration / 60);

        // Fala a mensagem inicial
        this.falar(`Rota iniciada. Distância de ${distanciaKm} quilómetros. Tempo estimado: ${tempoMin} minutos.`);

        // Anuncia a primeira manobra
        if (segmentoOSRM.steps && segmentoOSRM.steps.length > 0) {
            this.passosRota = segmentoOSRM.steps;
            this.passoAtualIndex = 0;

            setTimeout(() => {
                const primeiroPasso = this.passosRota[0];
                if (primeiroPasso && primeiroPasso.instruction) {
                    this.falar(`Em ${primeiroPasso.distance.toFixed(0)} metros, ${primeiroPasso.instruction}`);
                }
            }, 3000);
        }
    }
};

// Captura qualquer clique no ecrã para libertar a voz
document.addEventListener('click', () => VozNavegacao.desbloquearAudio(), { once: true });

window.VozNavegacao = VozNavegacao;