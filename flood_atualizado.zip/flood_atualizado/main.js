// main.js - Mantido limpo para não conflitar com o mapa.js
console.log('Sistema de rotas e monitoramento inicializado com sucesso.');

// Endpoint do seu Back-end em Java Spring Boot
const API_URL = 'http://localhost:8080/path';

// Variável global compartilhada com o mapa.js
window.statusAtualMaquete = 'NORMAL';

// Função para buscar dados da API e atualizar a interface
async function buscarDadosDoRio() {
    try {
        const resposta = await fetch(API_URL);

        if (!resposta.ok) {
            throw new Error(`Erro na requisição: ${resposta.status}`);
        }

        const dados = await resposta.json();

        if (dados && dados.length > 0) {
            const ultimaLeitura = dados[0]; // Pega o registro mais recente retornado pelo Spring Boot

            // Atualiza a variável global de estado
            window.statusAtualMaquete = ultimaLeitura.status;

            // Elementos do DOM (HTML)
            const statusBox = document.querySelector('.status-box h3');
            const statusDesc = document.querySelector('.status-box p');
            const viasCount = document.getElementById('vias-count');
            const alagamentosCount = document.getElementById('alagamentos-count');

            // 1. Atualiza textos do Card de Status
            if (statusBox) {
                statusBox.innerText = `Estado ${ultimaLeitura.status}`;
            }

            if (statusDesc) {
                statusDesc.innerText = `Nível atual da água: ${ultimaLeitura.nivelAgua}m.`;
            }

            // 2. Lógica Dinâmica dos Contadores para a Maquete
            if (ultimaLeitura.status === 'NORMAL') {
                if (viasCount) viasCount.innerText = '00';
                if (alagamentosCount) alagamentosCount.innerText = '00';
            } else if (ultimaLeitura.status === 'ATENÇÃO') {
                if (viasCount) viasCount.innerText = '01';
                if (alagamentosCount) alagamentosCount.innerText = '01';
            } else if (ultimaLeitura.status === 'CRÍTICO') {
                if (viasCount) viasCount.innerText = '03';
                if (alagamentosCount) alagamentosCount.innerText = '02';
            }

            // 3. Atualiza o Marcador Piscante no Mapa
            atualizarMarcadorMapa(ultimaLeitura.status);

            console.log("Status atual da Maquete:", ultimaLeitura.status);
        }
    } catch (erro) {
        console.error("Erro ao conectar com o back-end Java:", erro);
    }
}

function atualizarMarcadorMapa(status) {
    const elBloqueio = document.getElementById('overlay-bloqueio');
    const labelBloqueio = document.getElementById('label-bloqueio');

    if (!elBloqueio) return;

    elBloqueio.classList.remove('status-critico', 'status-atencao');

    if (status === 'CRÍTICO') {
        elBloqueio.classList.add('status-critico');
        if (labelBloqueio) labelBloqueio.innerText = 'ÁREA INUNDADA';
    } else if (status === 'ATENÇÃO') {
        elBloqueio.classList.add('status-atencao');
        if (labelBloqueio) labelBloqueio.innerText = 'NÍVEL SUBINDO';
    }
}

// Polling: Consulta o Java continuamente a cada 2 segundos
document.addEventListener('DOMContentLoaded', () => {
    console.log('Sistema de rotas e monitoramento inicializado com sucesso.');
    buscarDadosDoRio();
    setInterval(buscarDadosDoRio, 2000);
});

function exibirAlertaBloqueioDestino() {
    // Procura por um container de alerta ou dispara uma notificação estilizada
    const containerAlerta = document.getElementById('mensagem-sistema') || document.body;

    const divAlerta = document.createElement('div');
    divAlerta.className = 'toast-alerta-bloqueio';
    divAlerta.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-ban"></i>
            <div>
                <strong>Rota Inviável!</strong>
                <p>O destino selecionado está em uma zona inundada. Escolha um ponto fora da área de risco.</p>
            </div>
        </div>
    `;

    containerAlerta.appendChild(divAlerta);

    // Remove a mensagem automaticamente após 4 segundos
    setTimeout(() => {
        divAlerta.remove();
    }, 4000);
}