// ==========================================
// 1. CONFIGURAÇÕES E CONSTANTES
// ==========================================
const ORS_API_KEY = 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImIyOTM5MjhlNzFiMTRjOTM4MTA5NDhiOWNkNTliMGEwIiwiaCI6Im11cm11cjY0In0='; 

// Ponto de origem fixo da maquete (São Carlos)
const pontoOrigem = [-47.8972, -22.0233]; 

// Coordenadas e Raio da Baixada do Cristo (Área Alagável)
const COORDS_CRISTO = [-47.9095, -22.0180];
const RAIO_BLOQUEIO_METROS = 250; // Raio em metros ao redor do Cristo

// Projeção das Coordenadas para Overlays do OpenLayers (EPSG:3857)
const coordsOrigemOverlay = ol.proj.fromLonLat(pontoOrigem);
const coordsCristoOverlay = ol.proj.fromLonLat([-47.9122, -22.0172]);
const coordsSubindoOverlay = ol.proj.fromLonLat([-47.8940, -22.0220]);

// Destinos padrão para atalhos
const destinosFixos = {
    'shopping': [-47.9170, -22.0185],
    'campinas': [-47.0608, -22.9064],
    'cristo': [-47.9095, -22.0180]
};

// ==========================================
// 2. INICIALIZAÇÃO DO MAPA (OpenLayers)
// ==========================================
const map = new ol.Map({
    target: 'map-container',
    layers: [
        new ol.layer.Tile({
            source: new ol.source.OSM()
        })
    ],
    view: new ol.View({
        center: ol.proj.fromLonLat([-47.8972, -22.0233]), // Centro de São Carlos
        zoom: 14
    })
});

// Camada Vetorial para desenhar a rota azul no mapa
const vetorSource = new ol.source.Vector();
const vetorLayer = new ol.layer.Vector({
    source: vetorSource,
    style: new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: '#3b82f6', // Cor azul da linha de rota
            width: 6
        })
    })
});
map.addLayer(vetorLayer);

// --- VINCULAÇÃO DOS OVERLAYS DO HTML COM O MAPA ---

// 1. Overlay do Usuário ("VOCÊ ESTÁ AQUI")
const elUser = document.getElementById('overlay-user');
if (elUser) {
    const overlayUser = new ol.Overlay({
        element: elUser,
        position: coordsOrigemOverlay,
        positioning: 'center-center'
    });
    map.addOverlay(overlayUser);
}

// 2. Overlay de Bloqueio ("BLOQUEIO TOTAL")
const elBloqueio = document.getElementById('overlay-bloqueio');
if (elBloqueio) {
    const overlayAlerta = new ol.Overlay({
        element: elBloqueio,
        position: coordsCristoOverlay,
        positioning: 'center-center'
    });
    map.addOverlay(overlayAlerta);
}

// 3. Overlay de Alerta Secundário ("NÍVEL SUBINDO")
const elSubindo = document.getElementById('overlay-subindo');
if (elSubindo) {
    const overlaySubindo = new ol.Overlay({
        element: elSubindo,
        position: coordsSubindoOverlay,
        positioning: 'center-center'
    });
    map.addOverlay(overlaySubindo);
}

// ==========================================
// 3. FUNÇÕES AUXILIARES DE VALIDAÇÃO
// ==========================================

// Calcula distância em metros entre duas coordenadas [lon, lat] (Fórmula Haversine)
function calcularDistanciaMetros(coords1, coords2) {
    const R = 6371e3;
    const rad = Math.PI / 180;
    const dLat = (coords2[1] - coords1[1]) * rad;
    const dLon = (coords2[0] - coords1[0]) * rad;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(coords1[1] * rad) * Math.cos(coords2[1] * rad) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Dispara o alerta estilizado e bloqueia a ação
function exibirAlertaBloqueioDestino() {
    const containerAlerta = document.getElementById('mensagem-sistema') || document.body;

    // Remove alertas antigos se existirem
    const alertaAntigo = document.querySelector('.toast-alerta-bloqueio');
    if (alertaAntigo) alertaAntigo.remove();

    const divAlerta = document.createElement('div');
    divAlerta.className = 'toast-alerta-bloqueio';
    divAlerta.innerHTML = `
        <div class="toast-content" style="display:flex; align-items:center; gap:10px;">
            <i class="fas fa-ban" style="font-size:1.5rem;"></i>
            <div>
                <strong>ROTA BLOQUEADA!</strong>
                <p style="margin:0; font-size:0.85rem;">O destino selecionado está na zona inundada da Baixada do Cristo.</p>
            </div>
        </div>
    `;

    containerAlerta.appendChild(divAlerta);

    setTimeout(() => {
        divAlerta.remove();
    }, 4500);
}

// ==========================================
// 4. PROCESSAMENTO E VALIDAÇÃO DA ROTA
// ==========================================
async function tracarR() {
    const inputDestino = document.getElementById('destination') || document.querySelector('input[type="text"]');
    let enderecoDigitado = inputDestino ? inputDestino.value.trim() : '';

    if (!enderecoDigitado) {
        alert('Por favor, digite um endereço ou cidade de destino!');
        return;
    }

    const buscaMin = enderecoDigitado.toLowerCase();
    let destinoCoordenadas = null;

    // A) Verifica se é um atalho conhecido
    if (buscaMin.includes('shopping') || buscaMin.includes('iguatemi')) {
        destinoCoordenadas = destinosFixos['shopping'];
    } else if (buscaMin.includes('campinas')) {
        destinoCoordenadas = destinosFixos['campinas'];
    } else if (buscaMin.includes('cristo') || buscaMin.includes('rotatória do cristo') || buscaMin.includes('rotatoria do cristo')) {
        destinoCoordenadas = destinosFixos['cristo'];
    } else {
        // B) Se não for atalho, busca na API de Geocodificação
        const textoComContexto = buscaMin.includes('são carlos') || buscaMin.includes('sao carlos') 
            ? enderecoDigitado 
            : `${enderecoDigitado}, São Carlos, SP`;

        destinoCoordenadas = await buscarCoordenadasPorEndereco(textoComContexto);
    }

    if (!destinoCoordenadas) {
        alert('Endereço não encontrado. Tente especificar o bairro ou número.');
        return;
    }

    // C) Executa a validação do destino e traça a rota
    processarRotaComSeguranca(destinoCoordenadas);
}

// Função principal de decisão de segurança
function processarRotaComSeguranca(coordsDestino) {
    const status = window.statusAtualMaquete || 'ATENÇÃO'; // Padrão ATENÇÃO conforme interface
    const estaAlagado = (status === 'ATENÇÃO' || status === 'CRÍTICO');

    // 1. Calcula a distância do destino até a Baixada do Cristo
    const distanciaAteCristo = calcularDistanciaMetros(coordsDestino, COORDS_CRISTO);

    // 2. Trava de Segurança: Se estiver alagado E o destino for no Cristo
    if (estaAlagado && distanciaAteCristo <= RAIO_BLOQUEIO_METROS) {
        vetorSource.clear(); // Limpa rotas do mapa
        exibirAlertaBloqueioDestino(); // Exibe o pop-up vermelho
        return; // Interrompe e NÃO chama a API de rota
    }

    // 3. Se for seguro (ou rota alternativa para outro lugar), chama a API
    buscarRotaNaAPI(pontoOrigem, coordsDestino, estaAlagado);
}

// ==========================================
// 5. GEOCODIFICAÇÃO (Endereço -> Coordenadas)
// ==========================================
async function buscarCoordenadasPorEndereco(texto) {
    const url = `https://api.openrouteservice.org/geocode/search?api_key=${ORS_API_KEY}&text=${encodeURIComponent(texto)}&boundary.rect=-48.00,-22.10,-47.80,-21.90`;

    try {
        const resposta = await fetch(url);
        const dados = await resposta.json();

        if (dados.features && dados.features.length > 0) {
            return dados.features[0].geometry.coordinates;
        }
        return null;
    } catch (erro) {
        console.error('Erro na geocodificação:', erro);
        return null;
    }
}

// ==========================================
// 6. REQUISIÇÃO DE ROTA (OpenRouteService API)
// ==========================================
function buscarRotaNaAPI(origem, destino, desviar) {
    const url = 'https://api.openrouteservice.org/v2/directions/driving-car/geojson';

    const dados = {
        coordinates: [origem, destino]
    };

    // Aplica os polígonos de bloqueio apenas se o alagamento estiver ativo
    if (desviar) {
        const poligonoBaixadaCristo = [
            [-47.9150, -22.0195],
            [-47.9090, -22.0195],
            [-47.9090, -22.0150],
            [-47.9150, -22.0150],
            [-47.9150, -22.0195]
        ];

        const poligonoCentro = [
            [-47.8940, -22.0220],
            [-47.8910, -22.0220],
            [-47.8910, -22.0190],
            [-47.8940, -22.0190],
            [-47.8940, -22.0220]
        ];

        dados.options = {
            avoid_polygons: {
                type: "MultiPolygon",
                coordinates: [
                    [poligonoBaixadaCristo],
                    [poligonoCentro]
                ]
            }
        };
    }

    fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': ORS_API_KEY,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(resultado => {
        if (resultado.features && resultado.features.length > 0) {
            vetorSource.clear();

            const format = new ol.format.GeoJSON();
            const rota = format.readFeature(resultado.features[0], {
                dataProjection: 'EPSG:4326',
                featureProjection: 'EPSG:3857'
            });

            vetorSource.addFeature(rota);
            map.getView().fit(vetorSource.getExtent(), { padding: [60, 60, 60, 60], duration: 1000 });
        } else if (desviar) {
            console.warn('Não foi possível desviar da área. Tentando rota direta...');
            buscarRotaNaAPI(origem, destino, false);
        } else {
            alert('Não foi possível calcular uma rota válida para este local.');
        }
    })
    .catch(erro => console.error('Erro ao buscar rota:', erro));
}

// ==========================================
// 7. VINCULAÇÃO GLOBAL E EVENTOS
// ==========================================

// Torna a função visível para a página HTML no clique do botão
window.tracarR = tracarR;

// Adiciona ouvinte para a tecla Enter no campo de busca assim que o DOM carregar
document.addEventListener('DOMContentLoaded', () => {
    const inputDestino = document.getElementById('destination') || document.querySelector('input[type="text"]');
    if (inputDestino) {
        inputDestino.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                tracarR();
            }
        });
    }
});